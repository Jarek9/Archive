package com.example.searchhighlight.model;

import lombok.Data;

@Data
public class SearchRequest {
    private String inputText;
    private String queryText;
}

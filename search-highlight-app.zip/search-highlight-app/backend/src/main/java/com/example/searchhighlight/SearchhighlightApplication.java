package com.example.searchhighlight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchhighlightApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchhighlightApplication.class, args);
	}

}
